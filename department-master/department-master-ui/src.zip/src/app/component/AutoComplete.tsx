import { Autocomplete, TextField as MuiTextField } from "@mui/material";

export interface AutoCompleteOption {
  label: string;
  value: string | number;
}

interface AutoCompleteProps {
  label: string;
  value: AutoCompleteOption | null;
  onChange: (value: AutoCompleteOption | null) => void;
  options: AutoCompleteOption[];
  error?: boolean;
  helperText?: string;
  required?: boolean;
  disabled?: boolean;
}

function AutoComplete({
  label,
  value,
  onChange,
  options,
  error,
  helperText,
  required,
  disabled,
}: AutoCompleteProps) {
  return (
    <Autocomplete
      size="small"
      options={options}
      value={value}
      disabled={disabled}
      disablePortal={false}
      forcePopupIcon={false}
      isOptionEqualToValue={(option, selected) =>
        option.value === selected.value
      }
      getOptionLabel={(option) => option?.label ?? ""}
      onChange={(_event, newValue) => {
        onChange(newValue);
      }}
      slotProps={{
        popper: {
          sx: {
            zIndex: 1500,
          },
        },
        paper: {
          sx: {
            maxHeight: 320,

            "& .MuiAutocomplete-option": {
              fontSize: 14,
            },
          },
        },
      }}
      renderInput={(params) => (
        <MuiTextField
          {...params}
          label={label}
          error={error}
          helperText={helperText}
          required={required}
        />
      )}
    />
  );
}

export default AutoComplete;
